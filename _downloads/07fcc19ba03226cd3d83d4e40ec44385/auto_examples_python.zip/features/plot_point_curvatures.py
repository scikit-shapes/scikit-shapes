"""
.. _point_curvatures_example:

How to compute local curvatures
==================================

We use the :meth:`~skshapes.PolyData.point_curvatures` method to compute local curvature values.
"""
